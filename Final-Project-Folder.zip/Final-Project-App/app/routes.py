from flask import render_template, flash, redirect, url_for
from app import app, db
from app.models import User, Post
# Import forms and any additional required functions

@app.route('/')
@app.route('/index')
def index():
    posts = Post.query.all()
    return render_template('index.html', posts=posts)

# Create the routes for registration, login, and new post
